package com.cognizant.reportservice.controller;
import com.cognizant.reportservice.dto.*; import com.cognizant.reportservice.service.ReportService;
import lombok.RequiredArgsConstructor; import org.springframework.http.*; import org.springframework.security.access.prepost.PreAuthorize; import org.springframework.web.bind.annotation.*; import java.util.List;
@RestController @RequestMapping("/reports") @RequiredArgsConstructor
public class ReportController {
    private final ReportService reportService;
    @PostMapping
    @PreAuthorize("hasAnyRole('PROGRAM_MANAGER','ADMINISTRATOR','COMPLIANCE_OFFICER','GOVERNMENT_AUDITOR')")
    public ResponseEntity<ReportResponseDto> generate(@RequestBody ReportRequestDto dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(reportService.generateReport(dto));
    }
    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('PROGRAM_MANAGER','ADMINISTRATOR','COMPLIANCE_OFFICER','GOVERNMENT_AUDITOR','SERVICE')")
    public ResponseEntity<ReportResponseDto> getById(@PathVariable Long id) {
        return ResponseEntity.ok(reportService.getReportById(id));
    }
    @GetMapping
    @PreAuthorize("hasAnyRole('PROGRAM_MANAGER','ADMINISTRATOR','COMPLIANCE_OFFICER','GOVERNMENT_AUDITOR')")
    public ResponseEntity<List<ReportResponseDto>> getAll() {
        return ResponseEntity.ok(reportService.getAllReports());
    }
    @GetMapping("/scope/{scope}")
    @PreAuthorize("hasAnyRole('PROGRAM_MANAGER','ADMINISTRATOR','COMPLIANCE_OFFICER','GOVERNMENT_AUDITOR')")
    public ResponseEntity<List<ReportResponseDto>> getByScope(@PathVariable String scope) {
        return ResponseEntity.ok(reportService.getReportsByScope(scope));
    }
}
