package com.cognizant.reportservice.dao;
import com.cognizant.reportservice.entity.Report; import org.springframework.data.jpa.repository.JpaRepository; import java.util.List;
public interface ReportRepository extends JpaRepository<Report, Long> { List<Report> findByScope(Report.ReportScope scope); }
