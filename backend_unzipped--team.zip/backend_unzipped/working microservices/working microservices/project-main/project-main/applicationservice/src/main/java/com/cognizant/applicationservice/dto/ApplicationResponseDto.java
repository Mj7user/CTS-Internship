package com.cognizant.applicationservice.dto;

import com.cognizant.applicationservice.entity.WelfareApplication;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class ApplicationResponseDto {
    private Long applicationId;
    private Long citizenId;
    private Long programId;
    private LocalDate submittedDate;
    private WelfareApplication.ApplicationStatus status;
    private LocalDateTime createdAt;
}
