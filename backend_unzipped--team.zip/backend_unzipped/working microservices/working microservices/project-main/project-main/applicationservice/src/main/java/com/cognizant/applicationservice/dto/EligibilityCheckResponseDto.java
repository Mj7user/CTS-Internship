package com.cognizant.applicationservice.dto;

import com.cognizant.applicationservice.entity.EligibilityCheck;
import lombok.*;
import java.time.LocalDate;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class EligibilityCheckResponseDto {
    private Long checkId;
    private Long applicationId;
    private Long officerId;
    private EligibilityCheck.CheckResult result;
    private LocalDate date;
    private String notes;
}
