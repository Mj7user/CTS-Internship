package com.cognizant.programservice.service;

import com.cognizant.programservice.dto.ProgramRequestDto;
import com.cognizant.programservice.dto.ProgramResponseDto;
import com.cognizant.programservice.entity.Program;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface ProgramService {
    ProgramResponseDto createProgram(ProgramRequestDto request);
    ProgramResponseDto getProgramById(Long id);
    Page<ProgramResponseDto> getAllPrograms(Pageable pageable);
    Page<ProgramResponseDto> getProgramsByStatus(Program.ProgramStatus status, Pageable pageable);
    Page<ProgramResponseDto> searchPrograms(String keyword, Pageable pageable);
    ProgramResponseDto updateProgram(Long id, ProgramRequestDto request);
    void updateProgramStatus(Long id, Program.ProgramStatus status);
    void deleteProgram(Long id);
}
