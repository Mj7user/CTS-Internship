package com.cognizant.programservice.exception;
public class ResourceNotFoundException extends RuntimeException { public ResourceNotFoundException(String m) { super(m); }

    public ResourceNotFoundException(String program, Long programId) {
    }
}
