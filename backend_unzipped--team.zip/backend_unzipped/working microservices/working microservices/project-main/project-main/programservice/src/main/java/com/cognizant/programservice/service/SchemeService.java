package com.cognizant.programservice.service;

import com.cognizant.programservice.dto.SchemeRequestDto;
import com.cognizant.programservice.dto.SchemeResponseDto;
import com.cognizant.programservice.entity.Scheme;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface SchemeService {

    SchemeResponseDto createScheme(SchemeRequestDto request);

    SchemeResponseDto getSchemeById(Long id);

    Page<SchemeResponseDto> getAllSchemes(Pageable pageable);

    List<SchemeResponseDto> getSchemesByProgram(Long programId);

    SchemeResponseDto updateScheme(Long id, SchemeRequestDto request);

    void updateSchemeStatus(Long id, Scheme.SchemeStatus status);

    void deleteScheme(Long id);
}