package com.cognizant.citizenservice.dto;

import jakarta.validation.constraints.NotNull;
import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class CitizenRegistrationDto {
    @NotNull(message = "userId is required")
    private Long userId;
}
