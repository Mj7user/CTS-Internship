package com.cognizant.citizenservice.service;

import com.cognizant.citizenservice.dao.CitizenDocumentRepository;
import com.cognizant.citizenservice.dto.*;
import com.cognizant.citizenservice.entity.CitizenDocument;
import com.cognizant.citizenservice.exception.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CitizenDocumentServiceImpl implements CitizenDocumentService {

    private final CitizenDocumentRepository documentRepository;

    @Override
    public DocumentResponseDto uploadDocument(DocumentRequestDto dto) {
        CitizenDocument doc = CitizenDocument.builder()
                .citizenId(dto.getCitizenId()).docType(dto.getDocType()).fileUri(dto.getFileUri()).build();
        return toDto(documentRepository.save(doc));
    }

    @Override
    public DocumentResponseDto getDocumentById(Long id) {
        return toDto(documentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Document not found: " + id)));
    }

    @Override
    public List<DocumentResponseDto> getDocumentsByCitizen(Long citizenId) {
        return documentRepository.findByCitizenId(citizenId).stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public DocumentResponseDto verifyDocument(Long id, String status) {
        CitizenDocument doc = documentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Document not found: " + id));
        doc.setVerificationStatus(CitizenDocument.VerificationStatus.valueOf(status.toUpperCase()));
        return toDto(documentRepository.save(doc));
    }

    private DocumentResponseDto toDto(CitizenDocument d) {
        return DocumentResponseDto.builder()
                .documentId(d.getDocumentId()).citizenId(d.getCitizenId())
                .docType(d.getDocType()).fileUri(d.getFileUri())
                .uploadedDate(d.getUploadedDate()).verificationStatus(d.getVerificationStatus()).build();
    }
}
