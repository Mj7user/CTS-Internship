package com.cognizant.citizenservice.controller;

import com.cognizant.citizenservice.dto.*;
import com.cognizant.citizenservice.service.CitizenDocumentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/documents")
@RequiredArgsConstructor
public class CitizenDocumentController {

    private final CitizenDocumentService documentService;

    @PostMapping
    @PreAuthorize("hasAnyRole('CITIZEN','WELFARE_OFFICER','ADMINISTRATOR')")
    public ResponseEntity<DocumentResponseDto> uploadDocument(@RequestBody DocumentRequestDto dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(documentService.uploadDocument(dto));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('CITIZEN','WELFARE_OFFICER','ADMINISTRATOR','COMPLIANCE_OFFICER','SERVICE')")
    public ResponseEntity<DocumentResponseDto> getDocument(@PathVariable Long id) {
        return ResponseEntity.ok(documentService.getDocumentById(id));
    }

    @GetMapping("/citizen/{citizenId}")
    @PreAuthorize("hasAnyRole('CITIZEN','WELFARE_OFFICER','ADMINISTRATOR','COMPLIANCE_OFFICER','SERVICE')")
    public ResponseEntity<List<DocumentResponseDto>> getDocumentsByCitizen(@PathVariable Long citizenId) {
        return ResponseEntity.ok(documentService.getDocumentsByCitizen(citizenId));
    }

    @PatchMapping("/{id}/verify")
    @PreAuthorize("hasAnyRole('WELFARE_OFFICER','ADMINISTRATOR')")
    public ResponseEntity<DocumentResponseDto> verifyDocument(@PathVariable Long id,
                                                              @RequestParam String status) {
        return ResponseEntity.ok(documentService.verifyDocument(id, status));
    }
}
