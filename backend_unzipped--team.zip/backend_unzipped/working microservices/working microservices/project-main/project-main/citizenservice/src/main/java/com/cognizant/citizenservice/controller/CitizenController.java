package com.cognizant.citizenservice.controller;

import com.cognizant.citizenservice.dto.*;
import com.cognizant.citizenservice.service.CitizenService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/citizens")
@RequiredArgsConstructor
public class CitizenController {

    private final CitizenService citizenService;

    @PostMapping("/register")
    @PreAuthorize("permitAll()")  // ← Change this
    public ResponseEntity<CitizenResponseDto> registerCitizen(@RequestParam Long userId, @RequestParam String name, @RequestParam String email, @RequestParam String contactInfo) {
        System.out.println("✓ Received citizen registration request for userId: " + userId);
        return ResponseEntity.status(HttpStatus.CREATED).body(citizenService.registerCitizen(userId, name, email, contactInfo));
    }


    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('CITIZEN','WELFARE_OFFICER','PROGRAM_MANAGER','ADMINISTRATOR','COMPLIANCE_OFFICER','GOVERNMENT_AUDITOR','SERVICE')")
    public ResponseEntity<CitizenResponseDto> getCitizenById(@PathVariable Long id) {
        return ResponseEntity.ok(citizenService.getCitizenById(id));
    }

    @GetMapping("/user/{userId}")
    @PreAuthorize("hasAnyRole('CITIZEN','WELFARE_OFFICER','ADMINISTRATOR','SERVICE')")
    public ResponseEntity<CitizenResponseDto> getCitizenByUserId(@PathVariable Long userId) {
        return ResponseEntity.ok(citizenService.getCitizenByUserId(userId));
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('WELFARE_OFFICER','PROGRAM_MANAGER','ADMINISTRATOR','COMPLIANCE_OFFICER','GOVERNMENT_AUDITOR')")
    public ResponseEntity<List<CitizenResponseDto>> getAllCitizens() {
        return ResponseEntity.ok(citizenService.getAllCitizens());
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('CITIZEN','WELFARE_OFFICER','ADMINISTRATOR')")
    public ResponseEntity<CitizenResponseDto> updateCitizen(@PathVariable Long id,
                                                            @Valid @RequestBody CitizenRequestDto dto) {
        return ResponseEntity.ok(citizenService.updateCitizen(id, dto));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMINISTRATOR')")
    public ResponseEntity<String> deleteCitizen(@PathVariable Long id) {
        citizenService.deleteCitizen(id);
        return ResponseEntity.ok("Citizen deleted successfully");
    }
}
