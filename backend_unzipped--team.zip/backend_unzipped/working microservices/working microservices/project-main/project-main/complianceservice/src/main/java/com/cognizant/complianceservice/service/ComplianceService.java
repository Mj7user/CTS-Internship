package com.cognizant.complianceservice.service;
import com.cognizant.complianceservice.dto.*; import java.util.List;
public interface ComplianceService {
    ComplianceRecordResponseDto createRecord(ComplianceRecordRequestDto dto);
    ComplianceRecordResponseDto getRecordById(Long id);
    List<ComplianceRecordResponseDto> getAllRecords();
    List<ComplianceRecordResponseDto> getRecordsByEntity(Long entityId);
}
