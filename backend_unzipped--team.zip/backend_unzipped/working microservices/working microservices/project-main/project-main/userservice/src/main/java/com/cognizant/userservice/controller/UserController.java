package com.cognizant.userservice.controller;

import com.cognizant.userservice.client.CitizenServiceClient;
import com.cognizant.userservice.dto.CitizenResponseDto;
import com.cognizant.userservice.dto.RegisterRequestDto;
import com.cognizant.userservice.dto.RegisterResponseDto;
import com.cognizant.userservice.dto.UserDto;
import com.cognizant.userservice.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;
    private final CitizenServiceClient citizenServiceClient;  // ← ADD THIS

    @PostMapping("/register")
    @PreAuthorize("hasRole('SERVICE')")
    public ResponseEntity<RegisterResponseDto> createUser(
            @RequestBody RegisterRequestDto registerRequestDto) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(userService.createUsers(registerRequestDto));
    }

    @GetMapping("/email/{email}")
    @PreAuthorize("hasAnyRole('SERVICE','WELFARE_OFFICER', 'PROGRAM_MANAGER' ," +
            " 'ADMINISTRATOR' , 'COMPLIANCE_OFFICER' , 'GOVERNMENT_AUDITOR' )" +
            " OR #email == authentication.name")
    public ResponseEntity<UserDto> getUserByEmail(@PathVariable String email){
        return ResponseEntity.ok(userService.findByEmail(email));
    }

    @GetMapping("/getallusers")
    @PreAuthorize("hasAnyRole('WELFARE_OFFICER', 'PROGRAM_MANAGER' ," +
            " 'ADMINISTRATOR' , 'COMPLIANCE_OFFICER' , 'GOVERNMENT_AUDITOR' )")
    public ResponseEntity<List<RegisterResponseDto>> getAllUser(){
        return ResponseEntity.ok(userService.getAllUser());
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('SERVICE','WELFARE_OFFICER', 'PROGRAM_MANAGER' ," +
            " 'ADMINISTRATOR' , 'COMPLIANCE_OFFICER' , 'GOVERNMENT_AUDITOR' )")
    public ResponseEntity<RegisterResponseDto> getUserById(@PathVariable Long id) {
        return ResponseEntity.ok(userService.getUserById(id));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('WELFARE_OFFICER', 'PROGRAM_MANAGER' ," +
            " 'ADMINISTRATOR' , 'COMPLIANCE_OFFICER' , 'GOVERNMENT_AUDITOR' )")
    public ResponseEntity<String> deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
        return ResponseEntity.ok("User deleted successfully");
    }

    // OPTIONAL: Only if you want to expose citizen registration directly
    // Otherwise, citizen is auto-registered when user registers with CITIZEN role
//    @PostMapping("/register-citizen")
//    public ResponseEntity<CitizenResponseDto> registerCitizen(@RequestParam Long userId) {
//        return ResponseEntity.status(HttpStatus.CREATED)
//                .body(citizenServiceClient.registerCitizen(userId));
//    }
}
