package com.cognizant.userservice.service;

import com.cognizant.userservice.client.CitizenServiceClient;
import com.cognizant.userservice.dao.UserRepository;
import com.cognizant.userservice.dto.RegisterRequestDto;
import com.cognizant.userservice.dto.RegisterResponseDto;
import com.cognizant.userservice.dto.UserDto;
import com.cognizant.userservice.entity.User;
import com.cognizant.userservice.exception.BusinessException;
import com.cognizant.userservice.exception.DuplicateResourceException;
import com.cognizant.userservice.exception.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService{

    private final UserRepository userRepository;
    private final CitizenServiceClient citizenServiceClient;  // ← ADD THIS DEPENDENCY


    @Override
    public RegisterResponseDto createUsers(RegisterRequestDto registerRequestDto) {

        if (userRepository.existsByEmail(registerRequestDto.getEmail())) {
            throw new
                    DuplicateResourceException("Email already registered: " + registerRequestDto.getEmail());
        }

        User.Role role;
        try {
            role = User.Role.valueOf(registerRequestDto.getRole().toUpperCase());

        } catch (IllegalArgumentException e) {
            throw new BusinessException("Invalid role: " + registerRequestDto.getRole());
        }
        if (role != User.Role.CITIZEN) {
            throw new BusinessException(
                    "Self-registration is only allowed for the CITIZEN role. " +
                            "Privileged accounts must be created by an Administrator.");
        }

        System.out.println("user service "+ role);

        User user = User.builder()
                .name(registerRequestDto.getName())
                .email(registerRequestDto.getEmail())
                .password(registerRequestDto.getPassword())
                .phone(registerRequestDto.getPhone())
                .role(role)
                .status(User.UserStatus.ACTIVE)
                .build();

        user = userRepository.save(user);

        try {
            citizenServiceClient.registerCitizen(user.getUserId(), user.getName(), user.getEmail(), user.getPhone());
            System.out.println("Citizen record created successfully for userId: " + user.getUserId());
        } catch (Exception e) {
            System.err.println("Failed to create citizen record: " + e.getMessage());
            e.printStackTrace();  // ← Add this to see full stack trace
        }


//        log.info("New user registered: {}", registerRequestDto.getEmail());

//        auditLogService.log(user.getUserId(), "REGISTER", "AUTH",
//                "New account registered with role: " + role.name(), null);

        return mapToResponse(user);
    }


    public UserDto findByEmail(String email){

        User user =userRepository.findByEmail(email).
                orElseThrow(()->new ResourceNotFoundException("User does not exist with email"+email));

        UserDto users=UserDto.builder()
                .userId(user.getUserId())
                .email(user.getEmail())
                .role(user.getRole())
                .password(user.getPassword())
                .build();

        return users;
    }

    @Override
    public List<RegisterResponseDto> getAllUser(){

        List<User> users=userRepository.findAll();

        return users.stream()
                .map(user -> RegisterResponseDto.builder()
                        .userId(user.getUserId())
                        .name(user.getName())
                        .email(user.getEmail())
                        .phone(user.getPhone())
//                        .role(user.getRole().toString())
                        .role(user.getRole())
//                        .status(user.getStatus().toString())
                        .status(user.getStatus())
                        .createdAt(user.getCreatedAt())
                        .updatedAt(user.getUpdatedAt())
                        .build())
                .toList();
    }

    @Override
    public RegisterResponseDto getUserById(Long id) {
        return mapToResponse(userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found", id)));
    }

    @Override
    @Transactional
    public void deleteUser(Long id) {

        if (!userRepository.existsById(id)) throw new ResourceNotFoundException("User", id);

//        auditLogService.log(currentUserId(), "DELETE_USER", "USER",
//                "Deleted user ID: " + id, null);
        userRepository.deleteById(id);
    }


    private RegisterResponseDto mapToResponse(User user) {
        return RegisterResponseDto.builder()
                .userId(user.getUserId())
                .name(user.getName())
                .email(user.getEmail())
                .phone(user.getPhone())
//                .role(user.getRole().toString())
                .role(user.getRole())
//                .status(user.getStatus().toString())
                .status(user.getStatus())
                .createdAt(user.getCreatedAt())
                .updatedAt(user.getUpdatedAt())
                .build();
    }
}
