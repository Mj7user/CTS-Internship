package com.cognizant.userservice.dto;

import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class CitizenResponseDto {
    private Long citizenId;
    private String name;
    private String email;
    private LocalDate dob;
    private String gender;
    private String address;
    private String contactInfo;
    private String status;
    private Long userId;
    private LocalDateTime createdAt;
}
