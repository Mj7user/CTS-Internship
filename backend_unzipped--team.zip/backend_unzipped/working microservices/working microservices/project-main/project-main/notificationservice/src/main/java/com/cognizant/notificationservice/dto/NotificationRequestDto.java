package com.cognizant.notificationservice.dto;
import com.cognizant.notificationservice.entity.Notification; import lombok.*;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class NotificationRequestDto {
    private Long userId;
    private Long entityId;
    private String message;
    private Notification.NotificationCategory category;
}
