package com.cognizant.notificationservice.controller;
import com.cognizant.notificationservice.dto.*; import com.cognizant.notificationservice.service.NotificationService;
import lombok.RequiredArgsConstructor; import org.springframework.http.*; import org.springframework.security.access.prepost.PreAuthorize; import org.springframework.web.bind.annotation.*; import java.util.List;
@RestController @RequestMapping("/notifications")
@RequiredArgsConstructor
//@CrossOrigin(origins = {"http://localhost:4200"})
public class NotificationController {
    private final NotificationService notificationService;

    // Internal endpoint called by other microservices via Feign
    @PostMapping("/internal")
    @PreAuthorize("hasRole('SERVICE')")
    public ResponseEntity<NotificationResponseDto> createInternal(@RequestBody NotificationRequestDto dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(notificationService.createNotification(dto));
    }



    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('CITIZEN','WELFARE_OFFICER','ADMINISTRATOR','SERVICE')")
    public ResponseEntity<NotificationResponseDto> getById(@PathVariable Long id) {
        return ResponseEntity.ok(notificationService.getNotificationById(id));
    }

    @GetMapping("/user/{userId}")
    @PreAuthorize("hasAnyRole('CITIZEN','WELFARE_OFFICER','ADMINISTRATOR','SERVICE')")
    public ResponseEntity<List<NotificationResponseDto>> getByUser(@PathVariable Long userId) {
        return ResponseEntity.ok(notificationService.getNotificationsByUser(userId));
    }

    @GetMapping("/user/{userId}/unread")
    @PreAuthorize("hasAnyRole('CITIZEN','WELFARE_OFFICER','ADMINISTRATOR','SERVICE')")
    public ResponseEntity<List<NotificationResponseDto>> getUnread(@PathVariable Long userId) {
        return ResponseEntity.ok(notificationService.getUnreadByUser(userId));
    }

    @PatchMapping("/{id}/read")
    @PreAuthorize("hasAnyRole('CITIZEN','WELFARE_OFFICER','ADMINISTRATOR')")
    public ResponseEntity<NotificationResponseDto> markRead(@PathVariable Long id) {
        return ResponseEntity.ok(notificationService.markAsRead(id));
    }
}
