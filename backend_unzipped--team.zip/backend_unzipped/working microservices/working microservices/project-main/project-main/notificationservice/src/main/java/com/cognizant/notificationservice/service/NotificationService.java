package com.cognizant.notificationservice.service;
import com.cognizant.notificationservice.dto.*; import java.util.List;
public interface NotificationService {
    NotificationResponseDto createNotification(NotificationRequestDto dto);
    NotificationResponseDto getNotificationById(Long id);
    List<NotificationResponseDto> getNotificationsByUser(Long userId);
    List<NotificationResponseDto> getUnreadByUser(Long userId);
    NotificationResponseDto markAsRead(Long id);
}
