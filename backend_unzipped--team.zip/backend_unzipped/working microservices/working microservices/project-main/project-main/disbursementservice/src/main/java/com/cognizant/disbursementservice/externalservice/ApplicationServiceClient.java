package com.cognizant.disbursementservice.externalservice;
import org.springframework.cloud.openfeign.FeignClient; import org.springframework.web.bind.annotation.*;
@FeignClient(name = "application-service")
public interface ApplicationServiceClient {
    @GetMapping("/applications/{id}") Object getApplicationById(@PathVariable Long id);
    @PatchMapping("/applications/{id}/status") Object updateApplicationStatus(@PathVariable Long id, @RequestParam String status);
}
