package com.cognizant.disbursementservice.dto;
import com.cognizant.disbursementservice.entity.Disbursement; import lombok.*; import java.math.BigDecimal; import java.time.*;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class DisbursementResponseDto { private Long disbursementId; private Long applicationId; private BigDecimal amount; private LocalDate date; private Disbursement.DisbursementStatus status; private LocalDateTime createdAt; }
