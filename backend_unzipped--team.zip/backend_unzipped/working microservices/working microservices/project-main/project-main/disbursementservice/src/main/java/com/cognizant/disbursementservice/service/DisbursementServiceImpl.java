package com.cognizant.disbursementservice.service;

import com.cognizant.disbursementservice.dao.DisbursementRepository;
import com.cognizant.disbursementservice.dto.DisbursementRequestDto;
import com.cognizant.disbursementservice.dto.DisbursementResponseDto;
import com.cognizant.disbursementservice.entity.Disbursement;
import com.cognizant.disbursementservice.exception.ResourceNotFoundException;
import com.cognizant.disbursementservice.externalservice.NotificationServiceClient;
import com.cognizant.notificationservice.dto.NotificationRequestDto;
import com.cognizant.notificationservice.entity.Notification;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class DisbursementServiceImpl implements DisbursementService {

    private final DisbursementRepository disbursementRepository;
    private final NotificationServiceClient notificationServiceClient;

    @Override
    public DisbursementResponseDto createDisbursement(DisbursementRequestDto dto) {
        Disbursement d = Disbursement.builder()
                .applicationId(dto.getApplicationId())
                .citizenId(dto.getCitizenId())  // ✅ SET CITIZEN ID
                .amount(dto.getAmount())
                .build();

        DisbursementResponseDto saved = toDto(disbursementRepository.save(d));

        // ✓ Send notification with userId
        try {
            NotificationRequestDto notificationDto = NotificationRequestDto.builder()
                    .userId(dto.getCitizenId())
                    .entityId(saved.getDisbursementId())
                    .message("Disbursement of " + dto.getAmount() + " has been initiated.")
                    .category(Notification.NotificationCategory.DISBURSEMENT)
                    .build();
            notificationServiceClient.createNotification(notificationDto);
            log.info("✓ Notification sent for disbursement: {}", saved.getDisbursementId());
        } catch (Exception e) {
            log.warn("⚠️ Failed to send notification: {}", e.getMessage());
        }

        return saved;
    }

    @Override
    public DisbursementResponseDto getDisbursementById(Long id) {
        return toDto(disbursementRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Disbursement not found: " + id)));
    }

    @Override
    public List<DisbursementResponseDto> getDisbursementsByApplication(Long applicationId) {
        return disbursementRepository.findByApplicationId(applicationId)
                .stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    @Override
    public List<DisbursementResponseDto> getAllDisbursements() {
        return disbursementRepository.findAll()
                .stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    @Override
    public DisbursementResponseDto updateStatus(Long id, String status) {
        Disbursement d = disbursementRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Disbursement not found: " + id));

        d.setStatus(Disbursement.DisbursementStatus.valueOf(status.toUpperCase()));

        DisbursementResponseDto updated = toDto(disbursementRepository.save(d));

        // ✓ Send status update notification
        try {
            NotificationRequestDto notificationDto = NotificationRequestDto.builder()
                    .userId(d.getCitizenId())  // ✅ NOW WORKS
                    .entityId(id)
                    .message("Your disbursement status has been updated to: " + status)
                    .category(Notification.NotificationCategory.DISBURSEMENT)
                    .build();
            notificationServiceClient.createNotification(notificationDto);
            log.info("✓ Status update notification sent for disbursement: {}", id);
        } catch (Exception e) {
            log.warn("⚠️ Failed to send notification: {}", e.getMessage());
        }

        return updated;
    }

    private DisbursementResponseDto toDto(Disbursement d) {
        return DisbursementResponseDto.builder()
                .disbursementId(d.getDisbursementId())
                .applicationId(d.getApplicationId())
                .amount(d.getAmount())
                .date(d.getDate())
                .status(d.getStatus())
                .createdAt(d.getCreatedAt())
                .build();
    }
}
