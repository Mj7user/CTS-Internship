package com.cognizant.disbursementservice; import org.junit.jupiter.api.Test; import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest class DisbursementserviceApplicationTests { @Test void contextLoads() {} }
