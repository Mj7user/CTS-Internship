package com.cognizant.disbursementservice.dto;
import com.cognizant.disbursementservice.entity.Payment; import lombok.*;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class PaymentRequestDto {
    private Long disbursementId;
    private Payment.PaymentMethod method;
}
