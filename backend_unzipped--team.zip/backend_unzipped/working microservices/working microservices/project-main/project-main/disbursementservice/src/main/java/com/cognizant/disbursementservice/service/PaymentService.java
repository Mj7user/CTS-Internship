package com.cognizant.disbursementservice.service;
import com.cognizant.disbursementservice.dto.*; import java.util.List;
public interface PaymentService {
    PaymentResponseDto createPayment(PaymentRequestDto dto);
    PaymentResponseDto getPaymentById(Long id);
    List<PaymentResponseDto> getPaymentsByDisbursement(Long disbursementId);
}
